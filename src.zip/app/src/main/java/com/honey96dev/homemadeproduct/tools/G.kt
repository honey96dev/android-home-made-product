package com.honey96dev.homemadeproduct.tools

import com.honey96dev.homemadeproduct.user.UserInfo

object G {
    val DATE_FORMAT = "MM/dd/yyyy"
    val DATE_FORMAT2 = "yyyy-MM-dd"
    var userInfo = UserInfo()

    val SERVER_URL = "http://173.199.122.197"
    val SERVER_SCHEME = "http"
    val SERVER_IP = "173.199.122.197"
}
